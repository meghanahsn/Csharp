﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Assignment2
{
    class DLL
    {
        Node head;
        Node tail;
        //check whether head and tail pointers are null
        public DLL()
        {
            head = null;
            tail = null;
        }
        public DLL(Node node)
        {
            //condition to check whether node is null
            if (node == null)
            {
                return;
            }
            else
            {
                // Assigning head and tail pointers to a node
                head = node;
                tail = node;
            }
        }

        public void displayList()
        {
            // Condition to check whether head pointer is null
            if (head == null)
            {
                //Display when data is empty
                Console.WriteLine("this is empty list");
            }
            else
            {
                // Call display function when data is present and head is non-empty
                displayList(head);
            }
        }

        public void displayList(Node node)
        {
            // Condition to check whether data is not present in a node
            if (node == null)
            {
                return;
            }
            else
            {
                // display current node data
                Console.Write(node.data+"\t");
                // Forward traverse of a  list 
                displayList(node.next);
            }
        }

        public void addNodeToTail(Node node)
        {
            // Condition to check whether data is not present in a node
            if (node == null)
            {
                return;
            }
            // Condition to check whether head pointer is null
            else if (head == null)
            {
                head = node;
                tail = node;
            }
            else
            {
                // Assigning tail pointer to current node in a list
                tail.next = node;
                // providing link to previous link to current node 
                node.prev = tail;
                // assigning null value to tail of next pointer
                node.next = null;
                //assigning current node as tail pointer
                tail = node;
            }
        }
        
        public void middleNumber(DLL dll,int size)
        {
            // Assigning head pointer of a list as starting node
            Node node = dll.head;
            int middle = 0;
            // Condition to check whether data is not present in a node
            if (node == null)
            {
                return;
            }
            else
            {
                // Condition to check whether data is  present in a list
                while (node != null)
                {
                    // condition to check the middle number in a list
                    if (middle == size / 2)
                    {
                        Console.WriteLine("middle index " + (middle+1) + " middle data " + node.data);
                    }
                    //traversing next node in a list 
                    node = node.next;
                    //iterating by 1 one every traversal of a node
                    middle++;
                }

            }

        }

        public void check_prime_num(DLL dll)
        {
            // Assigning head pointer of a list as starting node
            Node node = dll.head;
            // Condition to check whether data is not present in a node
            if (node == null)
            {
                return;
            }
            else
            {
                int count = 0;
                // Condition to check whether data is  present in a list
                while (node != null)
                {
                    // Declare Boolean variable and initialize value as true
                    Boolean flag_prime = true;
                    //Condition to check whether node value is 0 or 1
                    if (node.data == 0 || node.data == 1)
                        // Assign Boolean value as false
                        flag_prime = false;
                    // Checking for square root of number starting from 2 to array value
                    for (int j = 2; j <= Math.Sqrt(node.data); j++)
                    {
                        //Check whether remainder is 0
                        if ((node.data % j) == 0)
                        {
                            // Assign Boolean value as false
                            flag_prime = false;
                            //Console.WriteLine("Not Prime number" + node.data);
                        }
                    }
                    // Condition to count prime numbers
                    if (flag_prime)
                    {
                        Console.Write(node.data+"\t");
                        count++;
                    }
                    //Condition to check whether count is equal to 5
                    if (count == 5)
                    {
                        Console.WriteLine();
                        count = 0;
                    }
                    //traversing next node in a list
                    node = node.next;
                }
                
            }
        }

        public void reverseLinkedList(DLL dll)
        {
            // Creating node with null value
            Node temp = null;
            //Creating node and assigning head pointing value 
            Node current = dll.head;
            // Condition to check whether data is not present in a node
            if (current == null)
            {
                return;
            }
            else
            {
                /* swap next and prev for all nodes of doubly linked list */
                // Condition to check whether data is  present in a list
                while (current != null)
                {
                    // Assign current node of previous pointer to temp node
                    temp = current.prev;
                    //Assign nect pointer of current node as a previous pointer
                    current.prev = current.next;
                    // Assinging temp node as a next pointer of a current node
                    current.next = temp;
                    // Assigning current node of a previous pointer as a current node
                    current = current.prev;
                }
                // condition to check whether temp node is null
                if (temp != null)
                {
                    // if it is null assign previous pointer of a temp node as a head pointer of  a current node
                    dll.head = temp.prev;
                }
            }
            
        }

        public void display_intersection(DLL dll1,DLL dll2,DLL dll3)
        {
            // Create node object for 3 Lists
            Node node1 = dll1.head;
            Node node2 = dll2.head;
            Node node3 = dll3.head;
            // Condition to check whether data is  present in a list 1
            if (node1 == null)
            {
                return;
            }
            // Condition to check whether data is  present in a list 2
            else if (node2 == null)
            {
                return;
            }
            // Condition to check whether data is  present in a list 3
            else if (node3 == null)
            {
                return;
            }
            else
            {
                // Condition to check whether node is  present in a list 1
                while (node1!= null)
                {
                    // Assign first node as a head pointer data in list 2
                    node2 = dll2.head;
                    // Assign first node as a head pointer data in list 3
                    node3 = dll3.head;
                    // Condition to check whether node is  present in a list 2
                    while (node2 != null)
                    {
                        // condition to check whether list 1 node data is same as list 2 node data
                        if (node1.data == node2.data)
                        {
                            // Condition to check whether node is  present in a list 1
                            while (node3 != null)
                            {
                                // condition to check whether list 1 node data is same as list 3 node data
                                if (node1.data == node3.data)
                                { 
                                    //If all three files data is same display that number
                                   Console.Write(node1.data+"\t");  
                                }
                                // Traverse till end of the list 3
                                node3 = node3.next;
                            }
                        }
                        // Traverse till end of the list 2
                        node2 = node2.next;
                    }
                    // Traverse till end of the list 1
                    node1 = node1.next;
                }
            }
        }// end of display_intersection method

    } // end of DLL class
}
