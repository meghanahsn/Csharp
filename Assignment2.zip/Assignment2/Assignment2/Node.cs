﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    class Node
    {
        public Node prev;
        public Node next;
        public int data;

        // Parameterized Constructor 
        public Node(int data)
        {
            //Assigning value when instance of a class is created
            this.data = data;
        }
    }
}
