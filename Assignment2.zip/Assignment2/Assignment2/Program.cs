﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Assignment2
{
    class Program
    {
        static void Main(string[] args)
        {
            // Creating object for Doubly Linked list
            DLL dll1 = new DLL();
            DLL dll1Copy = new DLL();
            DLL dll2 = new DLL();
            DLL dll2Copy = new DLL();
            DLL dll3 = new DLL();
            DLL dll3Copy = new DLL();
            // Read path of  3 input file data
            string path1 = @"H:\Assignment2\Assignment2\file1.txt";
            string path2 = @"H:\Assignment2\Assignment2\file2.txt";
            string path3 = @"H:\Assignment2\Assignment2\file3.txt";
           
            StreamReader file1 = null, file2 = null, file3 = null;
            //Declare String variable for 3 files
            String myline1,myline2,myline3;
            //Declare integer variable for to count size of all 3 files
            int countList1 = 0, countList2 = 0, countList3 = 0;

            try
            {
               
                file1 = new StreamReader(path1);
                // condition to check file content is null
                if(file1 == null)
                {
                    // Display message when file is empty
                    Console.WriteLine("File is empty");
                }
                else
                {
                    // Read data from input file
                    while ((myline1 = file1.ReadLine()) != null)
                    {
                        // Add node to the end of the list
                        dll1.addNodeToTail(new Node(Int16.Parse(myline1.Trim())));
                        //count number of elements in list
                        countList1++;
                    }
                }
            }
            //If File doesn't exist display file not found exception
            catch (FileNotFoundException fileNotFoundEx)
            {
                Console.WriteLine("File - " + fileNotFoundEx.FileName + " not found");
            }

            try
            {                
                file2 = new StreamReader(path2);
                // condition to check file content is null    
                if (file2 == null)
                {
                    // Display message when file is empty
                    Console.WriteLine("File is empty");
                }
                else
                {
                    // Read data from input file
                    while ((myline2 = file2.ReadLine()) != null)
                    {
                        // Add node to the end of the list
                        dll2.addNodeToTail(new Node(Int16.Parse(myline2.Trim())));
                        //count number of elements in list
                        countList2++;
                    }
                }              
            }
            //If File doesn't exist display file not found exception
            catch (FileNotFoundException fileNotFoundEx)
            {
                Console.WriteLine("File - " + fileNotFoundEx.FileName + " not found");
            }

            try
            {
                file3 = new StreamReader(path3);
                // condition to check file content is null
                if (file3 == null)
                {
                    // Display message when file is empty
                    Console.WriteLine("File is empty");
                }
                else
                {
                    // Read data from input file
                    while ((myline3 = file3.ReadLine()) != null)
                    {
                        // Add node to the end of the list
                        dll3.addNodeToTail(new Node(Int16.Parse(myline3.Trim())));
                        //count number of elements in list
                        countList3++;
                    }
                }
                
            }
            //If File doesn't exist display file not found exception
            catch (FileNotFoundException fileNotFoundEx)
            {
                Console.WriteLine("File - " + fileNotFoundEx.FileName + " not found");
            }

            // Calling methods by using object of DLL class
            Console.WriteLine("First list");
            //dll1.displayList();
            Console.WriteLine("Size of list 1:" + countList1);
            // Calling Middle number method with 2 paramenters
            dll1.middleNumber(dll1, countList1);
            Console.WriteLine("Prime Numbers in list 1");
            // calling method to check prime number in list
            dll1.check_prime_num(dll1);
            Console.WriteLine();
            Console.WriteLine("Reverse of the list 1");
            //Assigning List 1 data
            dll1Copy = dll1;
            dll1.reverseLinkedList(dll1Copy);
            // method to display reverse list
            dll1Copy.displayList();

            Console.WriteLine();
            Console.WriteLine("Second list");
            //dll2.displayList();
            Console.WriteLine("Size of list 2:" + countList2);
            // Calling Middle number method with 2 paramenters
            dll2.middleNumber(dll2, countList2);
            Console.WriteLine("Prime Numbers in list 2 ");
            // calling method to check prime number in list
            dll2.check_prime_num(dll2);
            Console.WriteLine();
            Console.WriteLine("Reverse of the list 2");
            //Assigning List 2 data
            dll2Copy = dll2;
            dll2.reverseLinkedList(dll2Copy);
            // method to display reverse list
            dll2Copy.displayList();

            Console.WriteLine();
            Console.WriteLine("Third list");
            //dll3.displayList();
            Console.WriteLine("Size of list 2:" + countList3);
            // Calling Middle number method with 2 paramenters
            dll3.middleNumber(dll3, countList3);
            // calling method to check prime number in list
            Console.WriteLine("Prime Numbers in list 3 ");
            dll3.check_prime_num(dll3);
            Console.WriteLine();
            Console.WriteLine("Reverse of the list 3");
            //Assigning List 3 data
            dll3Copy = dll3;
            dll3.reverseLinkedList(dll3Copy);
            // method to display reverse list
            dll3Copy.displayList();
            Console.WriteLine();
            Console.WriteLine(" Intersection of numbers in  3 Lists");
            //methods to check intersecting numbers in 3 files
            dll1.display_intersection(dll1,dll2,dll3);
            Console.WriteLine("Press any key to continue");
            Console.ReadKey();
        }
    }
}
