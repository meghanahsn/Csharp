﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Collections;

namespace Assignment4
{
    class Program
    {
        static void Main(string[] args)
        {
            // Declare string variable with null value
            String txtWords = "";
            try
            {
                //Read the content of the file which has been mantioned on file path
                txtWords = File.ReadAllText("C:\\Users\\meghas23\\Downloads\\Assignment4\\Assignment4\\file1.txt");
            }
            // Throw an error message when unable to read data from file
            catch (IOException Iox)
            {
                //display error message
                Console.WriteLine("Error in Reading the File : " + Iox.Message);
            }
            // replace space charcter with carriage return or new line character
            txtWords = txtWords.Replace("\r\n", " ");
            // Split text data seperated by space character and store into array of string
            String[] single_word = txtWords.Split(' ');
            // Creation of object for HashTable
            Hashtable hashtable = new Hashtable();
            // retrieve each word from string array and assign those data as a key
            // Runtime of below mentioned for loop in Big-O notation is O(n)
            foreach (var key in single_word)
            {
                //condition to check whether key is empty
                if (key != "")
                {
                    // condition to check whether hashtable contains key
                    if (hashtable.ContainsKey(key))
                    {
                        try
                        {
                            // insert data into hashtable where table contains more than one same key 
                            int freq = int.Parse(hashtable[key].ToString());
                            // increment the Frequency count by 1
                            hashtable[key] = freq + 1;
                        }
                        // Throw an error message when hash key doesnot exist or data doesnot contain any object reference 
                        catch (NullReferenceException ex)
                        {
                            //display error message
                            Console.WriteLine("Unable to parse the text " + ex.Message);
                        }
                    }
                    else
                    {
                        // insert data into hashtable with frequency of 1
                        hashtable.Add(key, 1);
                    }
                }
            }

            //converting hash table data into dictionary for sorting purpose
            var dict = hashtable.Cast<DictionaryEntry>().ToDictionary(d => d.Key, d => d.Value);
            Console.WriteLine(" Words with maximum frequency ");
            try
            {
                // Sorting by descending order based on frequency in occurrence of data
                //Runtime of below mentioned for loop in Big-O notation is O(n)
                foreach (var author in dict.OrderByDescending(value => value.Value))
                {
                    // display hash table data with frequency
                    Console.WriteLine("word : {0}, Frequency : {1}", author.Key, author.Value);
                }

            }
            // Throw an error message when hash key doesnot exist or data doesnot contain any object reference 
            catch (NullReferenceException ex)
            {
                //display error message
                Console.WriteLine("Key not found in Hashtable" + ex.Message);
            }
            Console.ReadLine();
        }
    }
}
