﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Assignment3
{
    class Program
    {
        static void Main(string[] args)
        {
            // Creating object for Binary Search Tree
            BST bst1 = new BST();
            BST bst2 = new BST();
            BST bst3 = new BST();
            // Read path of  3 input file data
            string path1 = @"H:\Sem2\DS\Assignment3\Assignment3\file1.txt";
            string path2 = @"H:\Sem2\DS\Assignment3\Assignment3\file2.txt";
            string path3 = @"H:\Sem2\DS\Assignment3\Assignment3\file3.txt";

            StreamReader file1 = null, file2 = null, file3 = null;
            //Declare String variable for 3 files
            String myline1, myline2, myline3;

            try
            {
                file1 = new StreamReader(path1);
                // condition to check file content is null
                if (file1 == null)
                {
                    // Display message when file is empty
                    Console.WriteLine("File is empty");
                }
                else
                {
                    // Read data from input file
                    while ((myline1 = file1.ReadLine()) != null)
                    {
                        // Add node to the end of the list
                        bst1.insertNode(new Node(int.Parse(myline1.Trim())));
                    }
                    
                }
            }
            //If File doesn't exist display file not found exception
            catch (FileNotFoundException fileNotFoundEx)
            {
                Console.WriteLine("File - " + fileNotFoundEx.FileName + " not found");
            }
            

            try
            {

                file2 = new StreamReader(path2);
                // condition to check file content is null
                if (file2 == null)
                {
                    // Display message when file is empty
                    Console.WriteLine("File is empty");
                }
                else
                {
                    // Read data from input file
                    while ((myline2 = file2.ReadLine()) != null)
                    {
                        // Add node to the end of the list
                        bst2.insertNode(new Node(int.Parse(myline2.Trim())));
                    }

                }
            }
            //If File doesn't exist display file not found exception
            catch (FileNotFoundException fileNotFoundEx)
            {
                Console.WriteLine("File - " + fileNotFoundEx.FileName + " not found");
            }

            try
            {

                file3 = new StreamReader(path3);
                // condition to check file content is null
                if (file3 == null)
                {
                    // Display message when file is empty
                    Console.WriteLine("File is empty");
                }
                else
                {
                    // Read data from input file
                    while ((myline3 = file3.ReadLine()) != null)
                    {
                        // Add node to the end of the list
                        bst3.insertNode(new Node(int.Parse(myline3.Trim())));
                    }

                }
            }
            //If File doesn't exist display file not found exception
            catch (FileNotFoundException fileNotFoundEx)
            {
                Console.WriteLine("File - " + fileNotFoundEx.FileName + " not found");
            }

            // Calling totalNode method with 1 parameter and assigning total size of a tree to an integer variable
            int first_tree = bst1.totalNode(bst1.returnRoot());
            Console.WriteLine(" Size of first Binary Tree : " + first_tree);
            Console.WriteLine("Nodes of a first binary tree in descending order : ");
            // Calling decreasingOrder method with 1 parameter using object of BST class
            bst1.decreasingOrder(bst1.returnRoot());
            // Calling treeHeight method with 1 parameter using object of BST class
            Console.WriteLine("Height of first binary tree : "+ bst1.treeHeight(bst1.returnRoot()));
            Console.WriteLine("Numbers in first binary tree level by level");
            // Calling printLevelOrder method with 1 parameter using object of BST class
            BST.display_treeLevel(bst1.returnRoot());

            // Calling totalNode method with 1 parameter and assigning total size of a tree to an integer variable
            int sec_tree = bst2.totalNode(bst2.returnRoot());
            Console.WriteLine("Size of Second Binary Tree  : " + sec_tree);
            Console.WriteLine("Nodes of a second binary tree in descending order : ");
            // Calling decreasingOrder method with 1 parameter using object of BST class
            bst2.decreasingOrder(bst2.returnRoot());
            // Calling treeHeight method with 1 parameter using object of BST class
            //Console.WriteLine("Height of second binary tree : " + bst2.treeHeight(bst2.returnRoot()));
            Console.WriteLine("Numbers in second binary tree level by level");
            // Calling printLevelOrder method with 1 parameter using object of BST class
            BST.display_treeLevel(bst2.returnRoot());
            Console.WriteLine("Prime Numbers in second binary tree");
            // Calling check_prime_num method with 1 parameter using object of BST class
            bst2.sec_primeNumber(bst2.returnRoot());

            // Calling totalNode method with 1 parameter and assigning total size of a tree to an integer variable
            int three_tree = bst3.totalNode(bst3.returnRoot());
            Console.WriteLine("Size of Third Binary Tree : " + three_tree);
            Console.WriteLine("Nodes of a third binary tree in descending order : ");
            // Calling decreasingOrder method with 1 parameter using object of BST class
            bst3.decreasingOrder(bst3.returnRoot());
            // Calling treeHeight method with 1 parameter using object of BST class
            //Console.WriteLine("Height of third Binary tree : " + bst3.treeHeight(bst3.returnRoot()));
            Console.WriteLine("Numbers in third binary tree level by level");
            // Calling printLevelOrder method with 1 parameter using object of BST class
            BST.display_treeLevel(bst3.returnRoot());
            Console.ReadKey();
        }
    }
}
