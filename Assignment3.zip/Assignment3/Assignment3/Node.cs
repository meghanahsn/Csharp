﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3
{
    class Node
    {
        public int data;
        public Node left;
        public Node right;
        // Parameterized Constructor 
        public Node(int data)
        {
            //Assigning value when instance of a class is created
            this.data = data;
        }
    }
}
