﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3
{
    class BST
    {
        public Node root;
        int n = 1;
        //check whether root node is null
        public BST()
        {
            root = null;
        }
        public BST(Node newNode)
        {
            //Assign current node as a root node
            root = newNode;
        }

        public Node returnRoot()
        {
            //Return statement to return root node value
            return root;
        }
        public void insertNode(Node newNode)
        {
            //Create a new node named pointer and assign root node
            Node pointer = root;
            //Condition to check whether root node is null
            if (pointer == null)
            {
                //if null assign current node as root node
                root = newNode;
                return;
            }

            while (true)
            {
                // condition to check whether current node value is less than root node value
                if (newNode.data < pointer.data)
                {
                    //condition to check whether left node of root node is null
                    if (pointer.left == null)
                    {
                        //Assign current node as a left node of parent node
                        pointer.left = newNode;
                        break;
                    }
                    // assign root node pointer link to left pointer 
                    pointer = pointer.left;
                }
                else
                {
                    //condition to check whether right node of root node is null
                    if (pointer.right == null)
                    {
                        //Assign current node as a right node of parent node
                        pointer.right = newNode;
                        break;
                    }
                    // assign root node pointer link to right pointer 
                    pointer = pointer.right;
                }
            }
         }

        public int totalNode(Node root)
        {
            //condition to check whether root node is null
            if (root == null)
                return 0;
            //condition to check whether left node from parent node  is null
            if (root.left != null)
            {
                //increment n value by 1 to count total number of nodes
                n +=  1;
                //recursive call to total number of left nodes
                n = totalNode(root.left);
            }
            //condition to check whether right node from parent node  is null
            if (root.right != null)
            {
                //increment n value by 1 to count total number of nodes
                n += 1;
                //recursive call to total number of right nodes
                n = totalNode(root.right);
            }
            //return counted number of nodes in a tree
            return n;
        }

        public void decreasingOrder(Node root)
        {
            //Condition to check whether root node is not null 
            if (root != null)
            {
                //Recursive call to retrieve root node right pointer  
                decreasingOrder(root.right);
                //display right node value
                Console.Write("Node is " + root.data+"\n");
                //Recursive call to retrieve root node left pointer  
                decreasingOrder(root.left);
            }
        }

        public int treeHeight(Node node)
        {
            //Condition to check whether node is null
            if (node == null)
                return 0;
            else
            {
                // compute the depth of each subtree
                int left_height = treeHeight(node.left);
                int right_height = treeHeight(node.right);

                /* use the larger one */
                // Condition to check whether greater length of left or right subtree
                if (left_height > right_height)
                    return (left_height + 1);
                else return (right_height + 1);
            }
        }

        public static void display_treeLevel(Node root)
        {
            // condition to check whether root node is null  
            if (root == null)
                return;

            // Create an empty queue for level  
            // order tarversal  
            Queue<Node> q = new Queue<Node>();

            // Enqueue Root node and initialize height  
            q.Enqueue(root);

            while (true)
            {
                // nodeCount (queue size) indicates  
                // number of nodes at current level.  
                int nodeCount = q.Count;
                //condition to check whether total number of node is zero 
                if (nodeCount == 0)
                    break;

                // Dequeue all nodes of current level  
                // and Enqueue all nodes of next level  
                while (nodeCount > 0)
                {
                    //Assign peek node data of queue to a first node for dequeue
                    Node node = q.Peek();
                    //print peek node data
                    Console.Write(node.data + " ");
                    //dequeue current node
                    q.Dequeue();
                    //Condition to check whether left node from a parent node is not null
                    if (node.left != null)
                        //insert left node to the end of queue
                        q.Enqueue(node.left);
                    //Condition to check whether right node from a parent node is not null
                    if (node.right != null)
                        //insert right node to the end of queue
                        q.Enqueue(node.right);
                    //decrement count value by 1
                    nodeCount--;
                }
                Console.WriteLine();
            }
        }

        public void sec_primeNumber(Node root)
        {
            //condition to check whether root node of a tree is null
            if (root == null)
            {
                return;
            }

            //condition to check whether root node of a tree is not null
            if (root != null)
            {
                //Declare Boolean variable and initialize value as true
                Boolean flag_prime = true;
                //Condition to check whether current node value is 0 or 1
                if (root.data == 0 || root.data == 1)
                    // Assign Boolean value as false
                    flag_prime = false;
                // Checking for square root of number starting from 2 to array value
                for (int j = 2; j <= Math.Sqrt(root.data); j++)
                {
                    //Check whether remainder is 0
                    if ((root.data % j) == 0)
                    {
                        // Assign Boolean value as false
                        flag_prime = false;
                    }
                }
                // Condition to check whether flag variable is true
                if (flag_prime)
                {
                    //display prime number in a tree
                    Console.WriteLine(root.data);
                }
                //traverse left node of a tree
                sec_primeNumber(root.left);
                //traverse right node of a tree
                sec_primeNumber(root.right);
            }

        }
    }
}
