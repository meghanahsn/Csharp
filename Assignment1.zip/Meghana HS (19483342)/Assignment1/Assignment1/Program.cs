﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Assignment1
{
    class Program
    {
        static void q1MinimumNumber(int[] numb)
        {
            // Declare integer variable and initialize with 0  
            int i, minIndex = 0;
            //Declare integer variable and initialize first element of array
            int min = numb[0];
            // Traverse the array elements based on index value
            for (i = 0; i < numb.Length; i++)
            {
                //Condition to check minimum value in array
                if (min > numb[i])
                    //Assign minimum value to variable
                    min = numb[i];
                //condition to check minimum value is equal to array value
                if (min == numb[i])
                    // Assign index value to variable
                    minIndex = i;
            }
            // Display Minimum Number
            Console.WriteLine("Minimum number in an array: " + min);
            // Display position of Minimum Number
            Console.WriteLine("Position of minimum number in an array:" + minIndex);
        }

        static void q3primeNumber(int[] numArray)
        {
            // Declare integer variable and initialize with 0  
            int i, j, count = 0;
            // Declare Boolean variable and initialize value as true
            bool flag_prime = true;
            // Traverse the array elements based on index value
            for (i = 0; i < numArray.Length; i++)
            {
                //Condition to check whether array value is 0 or 1
                if (numArray[i] == 0 || numArray[i] == 1)
                    // Assign Boolean value as false
                    flag_prime = false;
                // Checking for square root of number starting from 2 to array value
                for (j = 2; j <= Math.Sqrt(numArray[i]); j++)
                {
                    //Check whether remainder is 0
                    if ((numArray[i] % j) == 0)
                    {
                        // Assign Boolean value as false
                        flag_prime = false;
                    }
                }
                // Condition to count prime numbers
                if (flag_prime)
                {
                    //Increment by value 1
                    count += 1;
                }
                flag_prime = true;
            }
            // Display Total number of prime numbers
            Console.WriteLine("Total number of prime number in an array: " + count);
        }

        static void q4averageNumber(int[] numArray)
        {
            // Declare integer variable and initialize with 0
            int i, sum = 0, countAvg = 0 ;
            // Declare Double variable
            Double average;
            //Declare and integer variable and initialize array length
            int total = numArray.Length;
            for (i = 0; i < numArray.Length; i++)
            {
                // Calculate sum of elements in array
                sum += numArray[i];
            }
            // Calculate average of all numbers in array 
            average = ((double)sum / total);
            // Display average number with decimal value two
            Console.WriteLine("Average of total number in an array: " + Math.Round(average, 2));
            for (i = 0; i < numArray.Length; i++)
            {
                // Condition to check array value is greater than average
                if (numArray[i] > average)
                {
                    countAvg += 1;
                    // Display value greater than average
                    //Console.WriteLine("Bigger than Average" + numArray[i]);
                }
            }
            Console.WriteLine("Total count of values bigger than Average: " + countAvg);
        }

        static void q5oddEven(int[] numArray)
        {
            // Declare integer variable and initialize with 0
            int i, countOdd = 0, countEven = 0;
            // Traverse the array elements based on index value
            for (i = 0; i < numArray.Length; i++)
            {
                //Check whether remainder is 0
                if ((numArray[i] % 2) == 0)
                {
                    // Shorthad increment
                    countEven += 1;
                    //Console.WriteLine("Even Number" + numArray[i]);
                }
                else
                {
                    // Shorthad increment
                    countOdd += 1;
                    //Console.WriteLine("Odd Number" + numArray[i]);
                }
            }
            //Display number of even number in array
            Console.WriteLine("Count of even numbers in an array: " + countEven);
            //Display number of odd number in array
            Console.WriteLine("Count of odd numbers in an array: " + countOdd);
        }

        static void q8equal(int[] numArray)
        {
            // Declare Boolean variable and initialize value as true
            bool flag_equal = true;
            // Traverse the array elements based on index value
            for (int i = 0; i < numArray.Length - 1; i++)
            {
                // Comparision of two numbers in array
                if (numArray[i] != numArray[i + 1])
                {
                    flag_equal = false;
                }
            }
            //condition to check whether array values are equal or not
            if (flag_equal)
            {
                Console.WriteLine("Number in array are equal");
                Console.WriteLine("Number in array are not different");
            }
                
            else
            {
                Console.WriteLine("Number in array are not equal");
                Console.WriteLine("Number in array are different");
            }
        }

        static void q10checkSorted(int[] numArray)
        {
            // Declare Boolean variable and initialize value as false
            bool sort_flag = false;
            // Traverse the array elements based on index value
            for (int i = 0; i < numArray.Length - 1; i++)
            {
                // Condidtion to check whether array elements are sorted or not either in ascending
                if ((numArray[i] > numArray[i + 1]) || (numArray[0] == numArray[numArray.Length - 1] && numArray[i] != numArray[i + 1]))
                {
                    sort_flag = true;
                }
            }
            // Condition to display whether array is sorted or not
            if (sort_flag)
                Console.WriteLine("Number are not sorted");
            else
                Console.WriteLine("Number are sorted");
        }

        static void Main(string[] args)
        {
            // Declare integer variable and initialize with 0   
            int i = 0;
            // Declare Integer array variable and define size of array
            int[] numArray = new int[11];
            //Console.WriteLine("Hello");
            
            // Read path of input file data
            string path = @"H:\Sem2\Meghana HS (19483342)\Assignment1\Assignment1\inputAssign.txt";
            StreamReader file = null;

            String myline;

            try
            {
                file = new StreamReader(path);
                // Read input file data 
                while ((myline = file.ReadLine()) != null)
                {
                    //convert each line of data into integer and store in array of String
                    numArray[i] = Int32.Parse(myline.Trim());
                   // increament array index value
                    i++;

                }
            }
            //If File doesn't exist display file not found exception
            catch (FileNotFoundException fileNotFoundEx)
            {
                Console.WriteLine("File - " + fileNotFoundEx.FileName + " not found");
            }
            // Display all elements stored in an array
            Console.WriteLine("Display Array elements");
            // Traverse array elements from index 0 till total length of the array
            for (i = 0; i < numArray.Length; i++)
            {
                Console.WriteLine("" + numArray[i]);
            }
            //Calling Method
            q1MinimumNumber(numArray);
            q3primeNumber(numArray);
            q4averageNumber(numArray);
            q5oddEven(numArray);
            q8equal(numArray);
            q10checkSorted(numArray);

            Console.WriteLine("Press any key to continue");
            Console.ReadKey();
        }
    }
}
